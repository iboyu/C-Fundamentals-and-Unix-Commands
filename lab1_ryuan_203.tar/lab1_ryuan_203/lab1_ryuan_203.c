/*
 * RongLian Yuan G01313261
 * CS 262, Lab section 203
 * <lab1: This is my first lab assignment and I will try my best.>
 */

#include <stdio.h>
int main(){
	char name[50] = "RongLian Yuan";
	printf("Hello world!\nMy name is %s\n",name);
	return 0;
}
